
module.exports.config = {
  name: "lovecheck",
  version: "1.0.0",
  hasPermission: 0,
  credits: "💖 𝐌𝐀𝐇𝐈𝐍",
  description: "Check your love future with someone special",
  commandCategory: "fun",
  usages: "lovecheck [your_crush_name]",
  cooldowns: 5,
};

module.exports.run = async function({ api, event, args }) {
  const yourName = "Mahin"; // তোমার নাম

  const partnerName = args.join(" ");
  if (!partnerName) return api.sendMessage("⚠️ উদাহরণ: lovecheck জান্নাত", event.threadID, event.messageID);

  const match = Math.floor(Math.random() * 100) + 1;
  let result = "";

  if (match >= 90) {
    result = "🌹💍 Wow! তোমাদের ভালোবাসা যেন সিনেমার গল্প! ভবিষ্যতে বিয়ে হওয়ার অনেক বেশি সম্ভাবনা আছে!";
  } else if (match >= 70) {
    result = "🥰 ভালোবাসা গভীর, তবে কিছু বাধা থাকবে। যদি একে অন্যকে বুঝতে পারো, ভবিষ্যত অনেক সুন্দর হতে পারে!";
  } else if (match >= 40) {
    result = "🙂 মাঝামাঝি সম্পর্ক। ভবিষ্যৎ নির্ভর করে তোমরা কতটা সিরিয়াস এবং বিশ্বস্ত থাকো তার উপর।";
  } else {
    result = "💔 সম্পর্কের পথে অনেক চ্যালেঞ্জ আসবে... যদি সত্যি ভালোবাসো তাহলে অনেক কিছু প্রমাণ করতে হবে!";
  }

  return api.sendMessage(
    `🔮 Love Future Checker 🔮\n\n👦 তোমার নাম: ${yourName}\n👧 প্রিয় নাম: ${partnerName}\n❤️ ম্যাচ পার্সেন্ট: ${match}%\n\n🔍 ফলাফল: ${result}`,
    event.threadID,
    event.messageID
  );
};
