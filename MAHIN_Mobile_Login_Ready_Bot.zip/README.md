
# MAHIN Messenger Bot (Mobile Login Ready)

✅ This bot is ready for running in mobile (Kiwi Browser / Termux / UserLand).

---

## 📲 How to Login with Facebook on Mobile:

1. Go to: [https://chat.openai.com/generate/appstate](https://chat.openai.com/generate/appstate)
2. Login with your Facebook cookie
3. Copy the generated **appstate.json**
4. Paste it inside the bot folder (where `index.js` is located)

---

## 🛠️ How to Run (Mobile with Node.js):
- Use Termux / UserLand or Cloud Shell
- Run the following:

```bash
pkg install nodejs -y
npm install
node index.js
```

---

## ⚙️ Configurable Bot Details
- Name: MAHIN
- Fun Command: `lovecheck`

---

Made with ❤️ by Mahin
